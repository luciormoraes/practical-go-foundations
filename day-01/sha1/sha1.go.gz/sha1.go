package main

import (
	"compress/gzip"
	"crypto/sha1"
	"fmt"
	"io"
	"os"
)

func main() {
	sig, err := sha1Sum("sha1.go")
	if err != nil {
		fmt.Printf("error: %s\n", err)
		os.Exit(1)
	}
	fmt.Println(sig)
}

// cat http.log.gz| gunzip |sha1sum
func sha1Sum(filename string) (string, error) {
	// idiom: acquire a resource, check for error, defer release
	file, err := os.Open(filename)
	if err != nil {
		fmt.Printf("can't open: %s\n", err)
		return "", err
	}
	defer file.Close() // deferred are called in LIFO order

	r, err := gzip.NewReader(file)
	if err != nil {
		fmt.Printf("error: %s\n", err)
		return "", err
	}
	// io.CopyN(os.Stdout, r, 100)
	defer r.Close()
	w := sha1.New()

	if _, err := io.Copy(w, r); err != nil {
		fmt.Printf("error: %s", err)
		return "", err
	}

	sig := w.Sum(nil)
	// fmt.Sprintf("%x\n", sig)
	return fmt.Sprintf("%x", sig), nil
}
